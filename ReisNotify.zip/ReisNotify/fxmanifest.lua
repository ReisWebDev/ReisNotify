fx_version 'adamant'

game 'gta5'

author '</Reis>'
description 'PPNotify'
version '5.4'

ui_page 'html/ui.html'

client_scripts {
	'client.lua',
}

files {
	'html/*.*'
}

export 'Alert'